# Mulai di GitHub Codespaces

Paket lengkap portofolio Zefan, versi 1.2.0. Foto, nama, email, WhatsApp,
TikTok, CV draf, HTML, CSS, JavaScript, backend opsional, dan aset sudah ada.
Paket ini mempertahankan tampilan dan konten versi sebelumnya.

## 1. Masukkan kode ke folder utama repo

ZIP ini tidak memiliki satu folder pembungkus tambahan. Di folder utama repo
harus terlihat `package.json`, `src/`, `content/`, dan `.devcontainer/`.
Jangan hanya menyimpan ZIP di repo: kode di dalamnya perlu diekstrak.

Bila ZIP sudah kamu upload ke folder utama di Explorer Codespaces, jalankan
perintah berikut dari terminal di folder tersebut:

```sh
unzip portofolio-zefan-codespaces.zip
```

Bila unzip menanyakan penimpaan README atau file lain yang sudah ada, periksa
terlebih dahulu. Jangan menimpa pekerjaan lain yang masih dibutuhkan.
Alternatifnya, ekstrak ZIP di perangkatmu lalu upload seluruh isinya ke repo,
termasuk file/folder yang diawali titik seperti `.devcontainer` dan `.gitignore`.
Arsip ZIP itu sendiri tidak perlu di-commit; `.gitignore` sudah mengecualikannya.

## 2. Aktifkan konfigurasi Codespaces

Jika kode sudah ada di repo sebelum Codespace dibuat, `.devcontainer/devcontainer.json`
akan digunakan saat Codespace dibuat. Konfigurasi ini menggunakan image Node.js 22,
menjalankan `npm ci --ignore-scripts && npm run build`, dan meneruskan port 4173.

Jika Codespace sudah terbuka sebelum file dimasukkan, buka Command Palette,
lalu jalankan `Codespaces: Rebuild Container`. Tunggu prosesnya selesai.
Simpan/commit pekerjaan lebih dulu sebelum rebuild.

Tanpa dev container khusus pun proyek dapat berjalan pada Node.js 22.12 atau
lebih baru. `node --version` menampilkan versi yang sedang digunakan. Bila
versinya terlalu lama, gunakan konfigurasi dev container yang disertakan.

## 3. Jalankan website

Dari terminal di folder yang berisi `package.json`:

```sh
npm run dev
```

Tidak perlu API key untuk melihat tampilan, chat FAQ lokal, atau tautan kontak.
Proyek ini tidak memiliki dependency npm pihak ketiga. Build dijalankan otomatis
saat server dinyalakan. Biarkan terminal tersebut berjalan.

Buka tab **PORTS**, cari **4173**, lalu buka alamat yang ditampilkan di browser.
Jika port belum muncul, gunakan **Add port** dan masukkan `4173`. Jangan mengetik
localhost secara manual di Safari HP: gunakan alamat yang diteruskan Codespaces.
Port tidak perlu diubah menjadi Public untuk kamu gunakan sendiri.

Alamat ini adalah pratinjau pengembangan, bukan deployment produksi yang telah
dibuat oleh paket ini. Tidak ada repo, Codespace, atau hosting pengguna yang
secara otomatis dibuat oleh arsip ini.

## Tempat mengedit

| Yang diubah | File sumber |
| --- | --- |
| Struktur/markup HTML | `src/render.mjs` |
| Warna, layout, responsif, animasi CSS | `src/styles.css` |
| Menu, tema, suara, form, filter, interaksi | `src/app.js` |
| Jawaban FAQ lokal | `src/assistant.js` dan `content/portfolio.json` |
| Renderer nama 3D | `src/name-3d.js` |
| Data profil, pengalaman, pendidikan, karya | `content/portfolio.json` |
| Foto, gambar karya, CV, mesh nama | `public/assets/` |
| API chat dan email | `api/` |
| Pengaturan layanan rahasia | `.env.local` (jangan di-commit) |

**HTML sudah disertakan di `dist/index.html`.** HTML itu adalah hasil build dari
`src/render.mjs` dan `content/portfolio.json`, bukan sumber utama yang perlu diedit.
Perubahan langsung pada `dist/` akan ditimpa build berikutnya. `preview.html`
adalah versi satu file untuk pratinjau, juga dihasilkan otomatis.

Setelah mengedit sumber, hentikan server dengan Ctrl+C, jalankan `npm run dev`
lagi, lalu refresh browser. Server ini tidak memakai hot reload.

```sh
npm run build  # Memperbarui dist/ dan preview.html.
npm test       # Build, lalu jalankan pengujian otomatis.
```

`dist/` dan `preview.html` disertakan di ZIP agar bisa diperiksa langsung, tetapi
sengaja diabaikan Git karena dapat dibuat ulang dari sumber. Untuk repo gunakan
semua sumber, bukan hanya `dist/`. Gunakan Source Control di Codespaces untuk
meninjau perubahan, commit, lalu push/sync ke repository milikmu.

## Fitur yang masih membutuhkan konfigurasi

Asisten bawaan adalah FAQ lokal, bukan model AI generatif. Form membuka draf di
aplikasi email, bukan mengirim otomatis. Kode backend AI/email sudah tersedia,
tetapi API key, pengirim email, dan proteksi produksi perlu diisi sendiri.
Lihat README.md sebelum mengaktifkan layanan eksternal; biaya dan ketersediaannya
mengikuti penyedia masing-masing. CV tetap draf untuk diperiksa.

Jangan masukkan rahasia ke `content/portfolio.json`, `src/`, atau `public/`.
Contoh variabel tersedia di `.env.example`; salin ke `.env.local` bila diperlukan.
File foto, kontak, dan CV dalam proyek ini memang dimaksudkan untuk tampil di
portofolio. Tinjau kembali sebelum memublikasikan repo atau website.

## Rujukan konfigurasi

- GitHub Docs, Introduction to dev containers:
  https://docs.github.com/en/codespaces/setting-up-your-project-for-codespaces/introduction-to-dev-containers
- GitHub Docs, Forwarding ports in your codespace:
  https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace
- Dev Containers, Node.js & JavaScript image:
  https://github.com/devcontainers/images/blob/main/src/javascript-node/README.md

Konfigurasi disusun berdasarkan dokumentasi tersebut. Validasi lokal paket
tercatat di `docs/REPO-PACKAGE-TESTS.md`; ini bukan klaim bahwa Codespace di akunmu
sudah dibuat atau diuji langsung.
