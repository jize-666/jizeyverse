import { randomUUID } from 'node:crypto';
import { contactSettings } from '../lib/settings.mjs';
import { json, fail, requireMethod, checkOrigin, readJSON, validateContact, HttpError } from '../lib/http.mjs';
import { limitRequest, limitGlobal } from '../lib/rate-limit.mjs';
export default async function handler(req, res) {
  try {
    requireMethod(req, res, 'POST'); checkOrigin(req);
    const input = validateContact(await readJSON(req, 16384));
    const cfg = contactSettings();
    if (!cfg.enabled) throw new HttpError(503, 'Pengiriman email belum dikonfigurasi. Pesan belum dikirim.');
    await limitRequest(req, 'contact', 5, 600);
    await limitGlobal('contact-day', 100, 86400);
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${cfg.key}`, 'Content-Type': 'application/json', 'Idempotency-Key': randomUUID() },
      body: JSON.stringify({ from: cfg.from, to: [cfg.to], reply_to: input.email, subject: `Pesan portofolio dari ${input.name}`, text: `Nama: ${input.name}\nEmail: ${input.email}\n\n${input.message}` }), signal: AbortSignal.timeout(12000)
    });
    if (!response.ok) throw new HttpError(503, 'Layanan email belum dapat menerima pesan. Pesan tidak ditandai sebagai terkirim.');
    const payload = await response.json();
    if (!payload.id) throw new HttpError(503, 'Status pengiriman belum dapat dipastikan.');
    json(res, 200, { ok: true, status: 'accepted', message: 'Pesan diterima layanan email untuk dikirim; penerimaan inbox belum dikonfirmasi.' });
  } catch (error) { fail(res, error); }
}
