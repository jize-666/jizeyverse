import { portfolio } from '../lib/portfolio.mjs';
import { aiSettings, contactSettings } from '../lib/settings.mjs';
import { json, fail, requireMethod } from '../lib/http.mjs';
export default async function handler(req, res) {
  try { requireMethod(req, res, 'GET'); json(res, 200, { assistant: aiSettings().enabled ? 'ai' : 'local', contact: contactSettings().enabled ? 'email' : portfolio.profile.email ? 'mailto' : 'draft' }); }
  catch (error) { fail(res, error); }
}
