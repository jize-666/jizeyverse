# Zefan - Portofolio Pribadi

Website satu halaman berbahasa Indonesia, dibuat dari **PRD Web Portofolio Pribadi.pdf versi 1.0 final** dan struktur visual video referensi yang dilampirkan. Identitas memakai data yang diberikan pemilik: **Zefan**, nama lengkap **Zefanya Abrar Aditya Putra**, foto profil, email, WhatsApp, dan TikTok. Riwayat pendidikan dan pekerjaan tidak diubah.

## Paket repo dan Codespaces

Untuk alur upload ZIP -> repo -> Codespaces, buka **[MULAI-DI-SINI.md](MULAI-DI-SINI.md)**.
Paket ini menyertakan `.devcontainer/devcontainer.json`, `.nvmrc`, dan konfigurasi
port **4173**. Letakkan `package.json` langsung di folder utama repo.

Perintah utama: `npm run dev`. Perintah `npm test` sekarang melakukan build dulu
agar dapat dijalankan dari checkout repo yang belum memiliki `dist/`/`preview.html`.

## Mulai dari sini

**Untuk melihat tanpa instalasi:** buka `preview.html` dalam browser yang menjalankan JavaScript. Gambar, stylesheet, kode, mesh nama, dan CV sudah tertanam dalam satu file. Tidak memerlukan koneksi internet untuk mode lokal.

Pada HP, pratinjau berkas di aplikasi Files/penampil dokumen dapat membatasi JavaScript. Buka dengan browser atau gunakan versi yang telah di-host. File ini bukan URL website yang sudah dipublikasikan. Tidak ada deployment ke akun pengguna yang dilakukan dalam pembuatan paket ini.

**Untuk mengedit proyek:** gunakan folder sumber ini. Dibutuhkan Node.js 22.12 atau lebih baru. Tidak ada dependency npm pihak ketiga dan tidak ada proses instalasi paket yang dibutuhkan untuk menjalankan proyek.

```sh
npm run dev
```

Buka alamat lokal yang dicetak terminal, biasanya `http://localhost:4173`. Setelah mengubah file, hentikan server dengan Ctrl+C, jalankan lagi, lalu muat ulang browser. Server sederhana ini tidak melakukan hot reload.

```sh
npm run build   # menghasilkan dist/ dan memperbarui preview.html
npm test        # 22 pengujian data, identitas, validasi, API, dan proteksi
```

## Yang tersedia

Desain terang/gelap dengan navbar pill melayang, menu HP, loader, role typing, bagian Tentang, riwayat pendidikan, timeline pengalaman dengan lima filter, grup skill, dua karya, dialog detail, form kontak, dan panel asisten. Ada reveal saat scroll, efek kedalaman kartu, mesh nama WebGL, partikel sentuh/kursor, suara interaksi singkat, dan tombol mute. Tema serta mute disimpan ketika browser mengizinkan penyimpanan lokal; riwayat chat hanya untuk sesi tab.

Lima pengalaman yang ditampilkan: Web Developer & AI Founder; Staff Kebun Cultivia; Crew Rumah Makan Little Tiam; Freelancer Sortir Paket J&T; Freelance Waiters Burjo. Cultivia memiliki tujuh tanggung jawab dalam satu kartu, sedangkan Little Tiam memperlihatkan jalur Waiters > Barista > Kitchen > Wakil kapten. Kategori Organisasi memiliki keadaan kosong, bukan pengalaman rekaan.

Dua karya awal: website ini dan studi kasus Catatan Progres Harian Kebun. Gambar website adalah tangkapan layar implementasi ini. Gambar catatan adalah ilustrasi **template kosong**, bukan dokumen/foto asli Cultivia. Tombol unduh template menghasilkan TXT yang bisa diedit.

## Mode lokal bukan integrasi layanan

| Fitur | Kondisi bawaan | Setelah konfigurasi |
| --- | --- | --- |
| Asisten | FAQ lokal dari konten portofolio; diberi label tanpa AI | Jawaban model melalui `/api/chat` |
| Form kontak | Validasi; membuka draf di aplikasi email ke zeyvee116@gmail.com. Pengguna menekan Kirim sendiri | Pengiriman langsung melalui `/api/contact` dan Resend |
| Kontak langsung | Email, WhatsApp +62 821-3590-2520, TikTok @tanzuyuuu | Tidak memerlukan API untuk membuka tautan |
| CV | PDF draf dua halaman, sudah berisi identitas, kontak, dan foto pemilik | Periksa seluruh isinya sebelum dijadikan CV final |
| Nama 3D | Mesh khusus tulisan Zefan, sudah dibentuk ulang | Fallback 2D ketika WebGL tidak tersedia atau reduced motion aktif |

Mode server ditentukan lewat `/api/status`. Pada hosting statis atau file tunggal, asisten tetap lokal dan form tidak berpura-pura mengirim pesan. Jika model gagal, antarmuka menyatakan kegagalan dan menandai jawaban pengganti sebagai lokal.

## Mengedit data profil

Edit **`content/portfolio.json`**. Jangan memasukkan API key di sini: file ini adalah konten publik dan disertakan dalam browser.

```json
{
  "name": "Zefan",
  "fullName": "Zefanya Abrar Aditya Putra",
  "displayNameIsPlaceholder": false,
  "initial": "z",
  "location": "",
  "email": "zeyvee116@gmail.com",
  "phone": "+6282135902520",
  "phoneDisplay": "+62 821-3590-2520",
  "portrait": "assets/profile.webp",
  "portraitAlt": "Foto profil Zefan, Zefanya Abrar Aditya Putra",
  "cv": "assets/CV-Draf-Zefan.pdf",
  "cvIsDraft": true,
  "socials": {
    "whatsapp": "https://wa.me/6282135902520?s=p",
    "tiktok": "https://www.tiktok.com/@tanzuyuuu"
  }
}
```

Cuplikan di atas adalah contoh field di `profile`, bukan seluruh file JSON. Simpan foto dan CV final di `public/assets/`. WhatsApp dan TikTok ada di `profile.socials`. GitHub, LinkedIn, dan Instagram tetap kosong karena belum diberikan; tautan kosong tidak ditampilkan. `fullName` tampil di Tentang, CV, metadata penulis, serta jawaban asisten; nama utama di hero adalah `profile.name`.

Seluruh `experience`, `education`, `skillGroups`, dan `projects` juga berada di file itu. Susun pengalaman dari tanggal mulai terbaru. Setelah mengubah urutan/isi, jalankan build. Tambahkan tautan repository hanya setelah repository benar-benar tersedia. Jangan mengganti label teknis Dasar/Belajar atau menambahkan angka pencapaian yang belum terverifikasi.

Informasi yang masih belum diisi: domisili, GitHub, LinkedIn, Instagram, dan repository. Foto, nama lengkap, panggilan, email, telepon/WhatsApp, dan TikTok sudah diperbarui. Nama sekolah tidak dipakai untuk menyimpulkan domisili. Tidak ada IPK atau status ketersediaan kerja yang dikarang.

CV bawaan tetap berlabel **draf** agar bisa ditinjau sebelum dipakai melamar. Identitas dan kontaknya sudah sesuai data pemilik. Perubahan JSON tidak otomatis menulis ulang PDF. Regenerasi opsional (memerlukan Python, ReportLab, dan Pillow):

```sh
python scripts/generate_cv.py
npm run build
```

Atau ganti PDF dengan CV final milikmu, lalu ubah `profile.cv` dan `cvIsDraft` sesuai berkas yang dipakai. Foto web adalah salinan WebP dari foto unggahan pemilik; metadata foto asli tidak ikut dimasukkan.

## AI dan email: konfigurasi server

Salin `.env.example` menjadi `.env.local` untuk pengembangan. Untuk deployment, masukkan nilainya ke pengaturan environment hosting, bukan ke source publik.

```dotenv
AI_PROVIDER=gemini
AI_MODEL=gemini-2.5-flash-lite
GEMINI_API_KEY=
RESEND_API_KEY=
EMAIL_FROM=
CONTACT_TO=zeyvee116@gmail.com
SITE_URL=
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
RATE_LIMIT_SALT=
```

`AI_MODEL` mengikuti model yang disebut PRD sebagai nilai awal, bukan jaminan bahwa model tersebut tersedia bagi setiap akun. Pilih model yang masih tersedia untuk akunmu dengan mengubah environment variable, lalu deploy ulang. Periksa dokumentasi model, biaya, dan batas pemakaian penyedia sebelum mengaktifkannya. Tidak ada klaim bahwa penggunaan layanan eksternal pasti gratis.

Untuk penyedia API kompatibel Chat Completions: gunakan `AI_PROVIDER=openai-compatible`, `AI_BASE_URL` berisi base URL HTTPS sampai `/v1`, `AI_API_KEY`, dan `AI_MODEL` milik penyedia tersebut. Adapter ini memakai endpoint `/chat/completions`; jangan menganggap semua penyedia mendukung format identik tanpa pengujian.

`EMAIL_FROM` harus merupakan pengirim yang diizinkan oleh akun Resend. `CONTACT_TO` merupakan penerima yang kamu tentukan di server. Email pengunjung hanya menjadi `reply_to`, tidak bisa mengganti tujuan email. Status sukses berarti layanan menerima pesan untuk dikirim, bukan konfirmasi pesan sudah sampai inbox.

**Produksi memerlukan proteksi rate limit yang persisten.** Isi Upstash REST URL/token dan salt rahasia minimal 24 karakter. Jika `NODE_ENV=production` atau `VERCEL=1`, integrasi berbayar tidak diaktifkan tanpa proteksi tersebut. Jika layanan pembatasan gagal, endpoint menolak permintaan; tidak diam-diam meneruskan panggilan berbiaya.

Batas bawaan: chat 10 permintaan/menit per IP, AI 60/hari per IP dan 100/hari untuk seluruh situs; email 5/10 menit per IP dan 100/hari untuk seluruh situs. Body maksimal 16 KB, chat 600 karakter, pesan email 20-4.000 karakter. Batas ini bukan pengganti pembatasan anggaran di akun penyedia.

Tidak ada cookie autentikasi, database chat, atau analytics pada versi ini. FAQ lokal tidak mengirim pertanyaan ke model. Ketika AI/email diaktifkan, isi terkait dikirim ke penyedia layanan. Rate limiter menyimpan hash IP ber-HMAC dan hitungan dengan TTL, bukan pesan pengunjung. Retensi log di hosting/penyedia mengikuti pengaturan akun masing-masing.

## Hosting

Paket menyertakan `vercel.json` untuk build `npm run build`, output `dist`, dan tiga endpoint Node di `api/`. Impor repository berisi **seluruh folder proyek**, bukan hanya `dist`, bila ingin mengaktifkan API. Pilih Node.js yang kompatibel, isi environment, dan uji deployment dari browser sebelum membagikan URL.

Untuk hosting statis, isi `dist/` bisa diunggah ke penyedia hosting statis; integrasi Node tidak ikut berjalan. Versi itu tetap memiliki FAQ lokal serta formulir yang membuka draf di aplikasi email.

Pengaturan indeks mesin pencari **sengaja noindex** sampai website siap dipublikasikan. Identitas sudah dikonfirmasi (`profile.displayNameIsPlaceholder=false`). Saat domain tersedia dan kamu siap merilis, atur `site.allowIndexing=true` dan `SITE_URL` menjadi origin HTTPS website yang benar. Build menghasilkan canonical URL, Open Graph, robots.txt, dan sitemap. Semua section memiliki heading semantik pada satu halaman, bukan metadata halaman terpisah.

## 3D, performa, dan aksesibilitas

Nama menggunakan mesh huruf ekstrusi: bidang depan/belakang, bevel, dinding, normal permukaan, pencahayaan, kilau material, dan gerakan dengan damping. Implementasi ini memakai **WebGL langsung**, bukan Three.js. Mesh adalah bentuk nama yang sudah dibentuk, bukan file font. Tidak ada font yang didistribusikan.

Teks HTML tetap menjadi heading yang dapat dibaca pembaca layar dan fallback. Saat tidak ada WebGL, nama berubah, reduced motion aktif, atau kondisi perangkat terdeteksi kurang sesuai, teks 2D tetap terlihat. Resolusi bisa diturunkan saat interaksi lambat. Deteksi hemat daya berbasis heuristik yang tersedia di browser; tidak semua mode hemat daya OS bisa diketahui situs.

Untuk mengganti mesh nama, tersedia generator opsional `scripts/bake_name_mesh.py`. Generator membutuhkan Python dengan numpy, matplotlib, shapely (mendukung constrained_delaunay_triangles), serta font lokal milikmu. Jalankan:

```sh
python scripts/bake_name_mesh.py --font /path/ke/font-lokal.ttf
npm run build
```

Jangan mengunggah file font yang lisensinya tidak mengizinkan distribusi. Generator hanya menulis geometri nama ke `public/assets/name-mesh.json`.

Momen kedalaman dibatasi pada nama hero, reveal judul, dan kartu karya. Tidak ada marquee. Suara menunggu interaksi yang diizinkan browser; tidak dapat memaksa autoplay pada browser yang memblokirnya. Mute tersimpan ketika storage diizinkan. Reduced motion menghilangkan gerakan/depth/partikel, tanpa memaksa mute. RAF berhenti saat tidak diperlukan atau tab tidak aktif.

Website memiliki label form, fokus keyboard, skip link, alt text, state tombol, dialog native, notifikasi live, dan layout responsif. **Target Lighthouse 90 serta 60 fps adalah target PRD, belum hasil pengukuran.** Safari/iPhone fisik, WebGL visual, suara pada perangkat asli, serta pengiriman AI/email nyata masih perlu diuji setelah konfigurasi. Lihat `docs/TEST-RESULTS.md`.

## Struktur proyek

```text
MULAI-DI-SINI.md           Panduan repo dan Codespaces
.devcontainer/            Node.js 22 dan forward port 4173
content/portfolio.json     Konten publik yang dapat diedit
src/render.mjs            Template HTML semantik
src/styles.css            Desain dan responsive layout
src/app.js                Interaksi halaman
src/assistant.js          FAQ lokal berbasis konten
src/name-3d.js             Renderer WebGL ringan
public/assets/            Gambar WebP, mesh, dan CV draf
api/                      Endpoint status, chat, kontak
lib/                      Validasi, konfigurasi, rate limit
scripts/                  Build, server lokal, generator mesh/CV opsional
tests/                    Pengujian Node tanpa dependency
docs/                     Catatan implementasi dan hasil pengujian
dist/                     Output website untuk hosting
preview.html              Versi mandiri satu file
```

## Rujukan implementasi

Riwayat kerja, pendidikan, serta prioritas fitur: PRD lampiran, khususnya halaman 3-6 dan Lampiran A-B halaman 9-11. Video digunakan untuk struktur komposisi, navbar, badge, timeline, serta panel chat, bukan sebagai sumber foto atau identitas pemilik. Foto, nama, email, WhatsApp, dan TikTok berasal dari pesan lanjutan pemilik.

Dokumentasi layanan untuk konfigurasi lanjutan:
- Gemini: https://ai.google.dev/api/generate-content
- Model dan penghentian model: https://ai.google.dev/gemini-api/docs/deprecations
- Resend: https://resend.com/docs/api-reference/emails/send-email
- Vercel Node functions: https://vercel.com/docs/functions/runtimes/node-js
- Upstash REST: https://upstash.com/docs/redis/features/restapi

Adaptasi stack mengikuti izin perubahan stack pada PRD halaman 7. Frontend memakai HTML/CSS/JavaScript dan WebGL native agar preview dapat dibuka tanpa instalasi dependency. Pengalaman pribadi belajar Three.js tetap ditulis sebagai skill dasar sesuai sumber; itu tidak berarti implementasi situs menggunakan library tersebut.
