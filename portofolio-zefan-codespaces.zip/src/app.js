(function () {
  'use strict';
  const data = JSON.parse(document.getElementById('portfolio-data').textContent);
  const iconPaths = JSON.parse(document.getElementById('icon-data').textContent);
  const $ = (s, base = document) => base.querySelector(s);
  const $$ = (s, base = document) => [...base.querySelectorAll(s)];
  const icon = name => `<svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.spark}</svg>`;
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const reduced = () => media.matches;
  const standalone = document.documentElement.dataset.standalone === 'true' || location.protocol === 'file:';
  const storage = {
    get(key, fallback = '', session = false) { try { return (session ? sessionStorage : localStorage).getItem(key) ?? fallback; } catch { return fallback; } },
    set(key, value, session = false) { try { (session ? sessionStorage : localStorage).setItem(key, value); } catch { /* Private mode and embedded previews may block storage. */ } }
  };
  let toastTimer, chatBusy = false, contactBusy = false, chatAbort = null, chatGeneration = 0;
  let runtime = { assistant: 'local', contact: data.profile.email ? 'mailto' : 'draft' };
  const chatStorageKey = 'portfolio-chat-v2-' + data.profile.name.toLowerCase();
  let history = [], rateTimes = [];
  function toast(text) { const el = $('#toast'); clearTimeout(toastTimer); el.textContent = text; el.classList.add('visible'); toastTimer = setTimeout(() => el.classList.remove('visible'), 4400); }
  const sound = (() => {
    let context = null, muted = storage.get('portfolio-muted', 'false') === 'true', last = 0;
    function update() { const b = $('#sound-toggle'); b.innerHTML = icon(muted ? 'mute' : 'volume'); b.setAttribute('aria-pressed', String(muted)); b.setAttribute('aria-label', muted ? 'Aktifkan suara' : 'Matikan suara'); b.title = muted ? 'Aktifkan suara' : 'Matikan suara'; }
    async function unlock() {
      if (muted || document.hidden) return;
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return;
      try { if (!context) context = new Audio(); if (context.state === 'suspended') await context.resume(); } catch { /* Audio is optional when browser policy denies it. */ }
    }
    function play(kind = 'click') {
      if (muted || !context || context.state !== 'running' || document.hidden) return;
      const now = context.currentTime;
      if (now - last < .07) return;
      last = now;
      try {
        const oscillator = context.createOscillator(), gain = context.createGain();
        const notes = { click: [620, 760, .045], swap: [450, 640, .09], slide: [340, 425, .07] };
        const [from, to, duration] = notes[kind] || notes.click;
        oscillator.type = 'sine'; oscillator.frequency.setValueAtTime(from, now); oscillator.frequency.exponentialRampToValueAtTime(to, now + duration);
        gain.gain.setValueAtTime(.0001, now); gain.gain.exponentialRampToValueAtTime(kind === 'slide' ? .013 : .023, now + .008); gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
        oscillator.connect(gain); gain.connect(context.destination); oscillator.start(now); oscillator.stop(now + duration + .02); oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
      } catch { /* Sound must never block a UI action. */ }
    }
    function toggle() { muted = !muted; storage.set('portfolio-muted', String(muted)); update(); if (!muted) unlock().then(() => play('swap')); toast(muted ? 'Suara dimatikan.' : 'Suara interaksi diaktifkan.'); }
    update();
    document.addEventListener('pointerdown', unlock, { passive: true });
    document.addEventListener('keydown', unlock, { passive: true });
    document.addEventListener('touchstart', unlock, { passive: true });
    document.addEventListener('visibilitychange', () => { if (document.hidden && context?.state === 'running') context.suspend().catch(() => {}); else if (!document.hidden && !muted && context) context.resume().catch(() => {}); });
    return { play, toggle };
  })();
  function updateTheme() {
    const dark = document.documentElement.dataset.theme === 'dark';
    const b = $('#theme-toggle'); b.innerHTML = icon(dark ? 'sun' : 'moon'); b.setAttribute('aria-pressed', String(dark)); b.setAttribute('aria-label', dark ? 'Aktifkan tema terang' : 'Aktifkan tema gelap');
    $('meta[name="theme-color"]').content = dark ? '#121714' : '#f8f9f7';
    window.dispatchEvent(new CustomEvent('portfolio-theme', { detail: { dark } }));
  }
  function toggleTheme() { const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = next; storage.set('portfolio-theme', next); updateTheme(); sound.play('swap'); }
  function closeMenu(focus = false) { $('#mobile-nav').hidden = true; $('#menu-toggle').setAttribute('aria-expanded', 'false'); $('#menu-toggle').setAttribute('aria-label', 'Buka menu navigasi'); $('#menu-toggle').innerHTML = icon('menu'); if (focus) $('#menu-toggle').focus(); }
  function toggleMenu() { const willOpen = $('#mobile-nav').hidden; $('#mobile-nav').hidden = !willOpen; $('#menu-toggle').setAttribute('aria-expanded', String(willOpen)); $('#menu-toggle').setAttribute('aria-label', willOpen ? 'Tutup menu navigasi' : 'Buka menu navigasi'); $('#menu-toggle').innerHTML = icon(willOpen ? 'close' : 'menu'); }
  updateTheme();
  $('#theme-toggle').addEventListener('click', toggleTheme);
  $('#sound-toggle').addEventListener('click', sound.toggle);
  $('#menu-toggle').addEventListener('click', toggleMenu);
  document.addEventListener('pointerdown', e => { if (!$('#mobile-nav').hidden && !e.target.closest('#mobile-nav,#site-header')) closeMenu(); });
  window.addEventListener('resize', () => { if (innerWidth > 800) closeMenu(); }, { passive: true });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('#mobile-nav').hidden) closeMenu(true); if (!$('#chat-panel').hidden) closeChat(); } });
  $$('a[href^="#"]').forEach(a => a.addEventListener('click', () => { closeMenu(); if (a.closest('dialog')) a.closest('dialog').close(); }));
  document.addEventListener('click', e => { if (e.target.closest('a,button,summary') && !e.target.closest('#sound-toggle,#theme-toggle,[data-filter]')) sound.play('click'); });
  // Reveal content only after JavaScript has successfully initialized it.
  let observer;
  function initializeReveal() {
    if (observer) observer.disconnect();
    if (reduced() || !('IntersectionObserver' in window)) { document.documentElement.classList.remove('motion-enabled'); $$('.reveal').forEach(el => el.classList.add('is-visible')); return; }
    document.documentElement.classList.add('motion-enabled');
    observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }), { threshold: .06, rootMargin: '0px 0px -18px 0px' });
    $$('.reveal:not(.is-visible)').forEach(el => observer.observe(el));
  }
  initializeReveal();
  media.addEventListener('change', initializeReveal);
  const sectionIds = ['home', 'about', 'experience', 'projects', 'contact'];
  let activeSection = 'home', ticking = false, lastSectionSound = 0;
  function trackScroll() {
    ticking = false;
    const y = scrollY, marker = 170;
    $('#site-header').classList.toggle('scrolled', y > 40);
    let current = 'home';
    sectionIds.forEach(id => { if ($('#' + id).getBoundingClientRect().top <= marker) current = id; });
    if (innerHeight + y >= document.documentElement.scrollHeight - 35) current = 'contact';
    if (current !== activeSection) {
      activeSection = current;
      $$('[data-nav]').forEach(a => { const isActive = a.dataset.nav === current; a.classList.toggle('active', isActive); if (isActive) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current'); });
      if (performance.now() - lastSectionSound > 850) { sound.play('slide'); lastSectionSound = performance.now(); }
    }
  }
  window.addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(trackScroll); ticking = true; } }, { passive: true });
  trackScroll();
  // The role text pauses while the tab is hidden and stops for reduced motion.
  let typingTimer, roleIndex = 0, charIndex = data.profile.roles[0].length, deleting = true;
  function typeStep() {
    if (reduced()) { $('#typed-role').textContent = data.profile.roles[0]; return; }
    if (document.hidden) { typingTimer = setTimeout(typeStep, 1000); return; }
    const text = data.profile.roles[roleIndex];
    charIndex += deleting ? -1 : 1;
    $('#typed-role').textContent = text.slice(0, Math.max(0, charIndex));
    let delay = deleting ? 25 : 52;
    if (deleting && charIndex <= 0) { deleting = false; roleIndex = (roleIndex + 1) % data.profile.roles.length; delay = 260; }
    else if (!deleting && charIndex >= text.length) { deleting = true; delay = 2300; }
    typingTimer = setTimeout(typeStep, delay);
  }
  if (!reduced()) typingTimer = setTimeout(typeStep, 2600);
  media.addEventListener('change', () => { clearTimeout(typingTimer); $('#typed-role').textContent = data.profile.roles[0]; roleIndex = 0; charIndex = data.profile.roles[0].length; deleting = true; if (!reduced()) typingTimer = setTimeout(typeStep, 2600); });
  function filterExperience(category) {
    let visible = 0;
    $$('[data-experience]').forEach(item => { const show = category === 'all' || item.dataset.category === category; item.hidden = !show; if (show) { visible++; item.classList.add('is-visible'); } });
    $$('.experience-filters [data-filter]').forEach(button => { const active = button.dataset.filter === category; button.classList.toggle('is-active', active); button.setAttribute('aria-pressed', String(active)); });
    $('#experience-empty').hidden = visible !== 0;
    $('.timeline').hidden = visible === 0;
    $('.experience-note').hidden = visible === 0;
    $('#filter-status').textContent = `${visible} pengalaman ditampilkan.`;
    sound.play('swap');
  }
  $$('[data-filter]').forEach(button => button.addEventListener('click', () => filterExperience(button.dataset.filter)));
  // All dialogs use native focus trapping, Escape handling, and focus restoration.
  let dialogReturnTarget = null;
  function openDialog(dialog, trigger) { if (!$('#chat-panel').hidden) closeChat(false); closeMenu(); dialogReturnTarget = trigger || document.activeElement; $$('dialog[open]').forEach(d => d.close()); dialog.showModal(); document.body.classList.add('modal-open'); $('.dialog-close', dialog)?.focus({ preventScroll: true }); }
  $$('dialog').forEach(dialog => {
    dialog.addEventListener('click', e => { if (e.target === dialog) { const r = dialog.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close(); } });
    dialog.addEventListener('close', () => { if (!$('dialog[open]')) { document.body.classList.remove('modal-open'); if (dialogReturnTarget?.isConnected && !dialogReturnTarget.closest('dialog')) dialogReturnTarget.focus({ preventScroll: true }); } });
  });
  $('#all-projects').addEventListener('click', e => openDialog($('#collection-dialog'), e.currentTarget));
  $$('[data-open-privacy]').forEach(b => b.addEventListener('click', e => openDialog($('#privacy-dialog'), e.currentTarget)));
  document.addEventListener('click', e => {
    const close = e.target.closest('[data-close-dialog]'); if (close) close.closest('dialog')?.close();
    const project = e.target.closest('[data-project]');
    if (project) {
      const template = document.getElementById('project-template-' + project.dataset.project);
      if (!template) return;
      const returnTo = project.closest('#collection-dialog') ? $('#all-projects') : project;
      $('#project-dialog-body').replaceChildren(template.content.cloneNode(true));
      openDialog($('#project-dialog'), returnTo);
    }
    if (e.target.closest('[data-download-template]')) {
      downloadText('Template-Catatan-Harian-Kebun.txt', 'TEMPLATE KOSONG - BUKAN DOKUMEN ASLI CULTIVIA\n\nTanggal: [tanggal kegiatan]\nArea / tanaman: [area dan jenis tanaman]\nKegiatan: [aktivitas yang dilakukan]\nTarget: [target]\nRealisasi / hasil panen: [hasil aktual]\nStatus target: [tercapai / belum tercapai]\nKendala: [kondisi di lapangan]\nTindak lanjut: [langkah berikutnya]\nDokumentasi: [foto/video yang sudah mendapat izin]\nDikirim kepada: [HRD / kepala cabang]\n\nCatatan: minta izin sebelum membagikan foto atau data internal.\n');
      toast('Template kosong diunduh; tidak memuat data internal.');
    }
  });
  function downloadBlob(name, blob) { const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = name; a.style.display = 'none'; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000); }
  function downloadText(name, text) { downloadBlob(name, new Blob([text], { type: 'text/plain;charset=utf-8' })); }
  $$('[data-cv]').forEach(link => link.addEventListener('click', e => {
    if (link.href.startsWith('data:application/pdf;base64,')) { e.preventDefault(); const bytes = Uint8Array.from(atob(link.href.split(',')[1]), c => c.charCodeAt(0)); downloadBlob((data.profile.cvIsDraft ? 'CV-Draf-' : 'CV-') + data.profile.name + '.pdf', new Blob([bytes], { type: 'application/pdf' })); }
  }));
  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) { try { await navigator.clipboard.writeText(text); return true; } catch { /* Continue to a clipboard fallback. */ } }
    const field = document.createElement('textarea'); field.value = text; field.setAttribute('readonly', ''); field.style.position = 'fixed'; field.style.opacity = '0'; document.body.append(field); field.select(); let copied = false;
    try { copied = document.execCommand('copy'); } catch { copied = false; } field.remove(); return copied;
  }
  function contactPresentation() {
    const mode = runtime.contact;
    $('#form-mode').textContent = mode === 'email' ? 'EMAIL AKTIF' : mode === 'mailto' ? 'APLIKASI EMAIL' : 'MODE DRAF';
    $('#contact-submit-text').textContent = mode === 'email' ? 'Kirim pesan' : mode === 'mailto' ? 'Buka aplikasi email' : 'Salin draf pesan';
    $('#form-explainer').textContent = mode === 'email' ? 'Nama, email, dan pesanmu dikirim melalui layanan email. Jangan sertakan informasi sensitif.' : mode === 'mailto' ? 'Draf dibuka di aplikasi email. Kamu tetap perlu menekan Kirim di aplikasi tersebut.' : 'Email belum diatur. Tombol ini menyalin pesan, bukan mengirimnya.';
  }
  contactPresentation();
  $('#contact-form').addEventListener('submit', async event => {
    event.preventDefault(); if (contactBusy) return;
    const form = event.currentTarget, status = $('#form-status'); status.textContent = ''; status.classList.remove('error');
    if (!form.reportValidity()) return;
    const fields = Object.fromEntries(new FormData(form));
    fields.name = fields.name.trim(); fields.email = fields.email.trim(); fields.message = fields.message.trim();
    if (fields.website || fields.name.length < 2 || fields.message.length < 20) { status.classList.add('error'); status.textContent = 'Periksa nama dan isi pesan. Pesan harus berisi setidaknya 20 karakter, bukan hanya spasi.'; return; }
    const text = `Nama: ${fields.name}\nEmail: ${fields.email}\n\n${fields.message}`;
    if (runtime.contact === 'draft') { const copied = await copyText(text); if (!copied) downloadText('Draf-Pesan-Portofolio.txt', text); status.textContent = copied ? 'Draf pesan disalin. Pesan belum dikirim ke pemilik portofolio.' : 'Draf pesan diunduh. Pesan belum dikirim ke pemilik portofolio.'; return; }
    if (runtime.contact === 'mailto') { const href = 'mailto:' + encodeURIComponent(data.profile.email) + '?subject=' + encodeURIComponent('Pesan portofolio dari ' + fields.name) + '&body=' + encodeURIComponent(text); window.location.href = href; status.textContent = 'Draf dibuka di aplikasi email. Pesan belum dikirim otomatis.'; return; }
    const button = $('.form-submit'); contactBusy = true; button.disabled = true; $('#contact-submit-text').textContent = 'Memproses pesan...';
    try {
      const response = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(fields), signal: AbortSignal.timeout(18000) });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || 'Pengiriman belum dapat dipastikan. Isi pesanmu tetap disimpan di form.');
      status.textContent = 'Pesan diterima layanan email untuk dikirim. Penerimaan di inbox belum dapat dipastikan.'; form.reset();
    } catch (error) { status.classList.add('error'); status.textContent = error.name === 'TimeoutError' ? 'Permintaan melewati batas waktu. Jangan kirim berulang-ulang; status pengiriman belum dapat dipastikan.' : error.message; }
    finally { contactBusy = false; button.disabled = false; contactPresentation(); }
  });
  // Session-only chat. Text content is never rendered as HTML.
  function saveHistory() { storage.set(chatStorageKey, JSON.stringify(history.slice(-20)), true); }
  function addMessage(role, text, mode = '', save = true) {
    const el = document.createElement('div'); el.className = 'message' + (role === 'user' ? ' user' : ''); el.textContent = text;
    if (mode && role !== 'user') { const meta = document.createElement('span'); meta.className = 'message-mode'; meta.textContent = mode === 'ai' ? 'Dihasilkan AI; periksa kembali detail penting.' : 'Jawaban lokal dari data portofolio'; el.append(meta); }
    $('#chat-messages').append(el); $('#chat-messages').scrollTop = $('#chat-messages').scrollHeight;
    if (save) { history.push({ role, text, mode }); history = history.slice(-20); saveHistory(); }
    return el;
  }
  function greet() { addMessage('assistant', `Halo! Aku asisten profil ${data.profile.name}. Mau tahu pengalaman kerja, skill yang sedang dipelajari, atau cerita di balik karyanya?`, 'local'); }
  try { const saved = JSON.parse(storage.get(chatStorageKey, '[]', true)); if (Array.isArray(saved)) history = saved.filter(m => ['user', 'assistant'].includes(m.role) && typeof m.text === 'string' && m.text.length <= 2500).slice(-20); } catch { history = []; }
  if (history.length) history.forEach(m => addMessage(m.role, m.text, m.mode, false)); else greet();
  function openChat(focus = true) { if ($('dialog[open]')) return; closeMenu(); $('#chat-panel').hidden = false; $('#chat-launcher').setAttribute('aria-expanded', 'true'); $('#chat-launcher').setAttribute('aria-label', 'Tutup asisten portofolio'); $('.chat-launcher-icon').innerHTML = icon('close'); if (focus) setTimeout(() => $('#chat-input').focus({ preventScroll: true }), 60); $('#chat-messages').scrollTop = $('#chat-messages').scrollHeight; }
  function closeChat(focus = true) { $('#chat-panel').hidden = true; $('#chat-launcher').setAttribute('aria-expanded', 'false'); $('#chat-launcher').setAttribute('aria-label', 'Buka asisten portofolio'); $('.chat-launcher-icon').innerHTML = icon('chat'); if (focus) $('#chat-launcher').focus({ preventScroll: true }); }
  $('#chat-launcher').addEventListener('click', () => $('#chat-panel').hidden ? openChat() : closeChat());
  $('#chat-close').addEventListener('click', () => closeChat());
  $$('[data-open-chat]').forEach(b => b.addEventListener('click', () => openChat()));
  $('#chat-reset').addEventListener('click', () => { chatGeneration++; chatAbort?.abort(); chatBusy = false; $('.chat-send').disabled = false; $$('#chat-suggestions button').forEach(b => b.disabled = false); history = []; $('#chat-messages').replaceChildren(); saveHistory(); greet(); toast('Riwayat percakapan pada tab ini dihapus.'); });
  function chatPresentation() {
    const isAI = runtime.assistant === 'ai';
    $('#chat-mode').replaceChildren(); const dot = document.createElement('span'); dot.className = 'status-dot'; dot.setAttribute('aria-hidden', 'true'); $('#chat-mode').append(dot, document.createTextNode(isAI ? 'Mode AI / konteks portofolio' : 'Mode lokal / tanpa AI'));
    $('#chat-privacy').textContent = isAI ? 'Pesan dikirim ke penyedia AI. Hindari data sensitif.' : 'Jawaban dari data portofolio, bukan AI generatif.';
  }
  async function ask(question) {
    const text = String(question).trim(); if (chatBusy || !text || text.length > 600) return;
    rateTimes = rateTimes.filter(t => Date.now() - t < 60000);
    if (rateTimes.length >= 10) { toast('Maksimal 10 pertanyaan per menit. Coba sebentar lagi.'); return; }
    rateTimes.push(Date.now()); chatBusy = true; const generation = chatGeneration;
    const previous = history.slice(-8).map(m => ({ role: m.role, text: m.text }));
    addMessage('user', text); $('#chat-input').value = ''; $('.chat-send').disabled = true; $$('#chat-suggestions button').forEach(b => b.disabled = true);
    const loading = document.createElement('div'); loading.className = 'message loading'; loading.setAttribute('aria-label', 'Asisten sedang mengetik'); loading.innerHTML = '<span></span><span></span><span></span>'; $('#chat-messages').append(loading); $('#chat-messages').scrollTop = $('#chat-messages').scrollHeight;
    let mode = 'local', answer;
    try {
      if (runtime.assistant === 'ai') {
        chatAbort = new AbortController(); const timeout = setTimeout(() => chatAbort.abort(), 16000);
        try {
          const response = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: text, history: previous }), signal: chatAbort.signal });
          const payload = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(payload.error || 'Layanan AI tidak tersedia.');
          if (typeof payload.answer !== 'string' || !payload.answer.trim()) throw new Error('Jawaban AI kosong.');
          answer = payload.answer.slice(0, 2400); mode = payload.mode === 'ai' ? 'ai' : 'local';
        } finally { clearTimeout(timeout); }
      } else { await new Promise(resolve => setTimeout(resolve, reduced() ? 100 : 520)); answer = window.PortfolioAssistant.localAnswer(text, data); }
    } catch {
      if (generation !== chatGeneration) return;
      answer = 'Layanan AI belum tersedia saat ini. Berikut jawaban dari data lokal:\n\n' + window.PortfolioAssistant.localAnswer(text, data); mode = 'local';
    } finally {
      loading.remove(); if (generation === chatGeneration) { chatBusy = false; $('.chat-send').disabled = false; $$('#chat-suggestions button').forEach(b => b.disabled = false); }
    }
    if (generation === chatGeneration && answer) addMessage('assistant', answer, mode);
  }
  $('#chat-form').addEventListener('submit', event => { event.preventDefault(); ask($('#chat-input').value); });
  $$('[data-question]').forEach(button => button.addEventListener('click', () => ask(button.dataset.question)));
  if (!standalone) {
    fetch('/api/status', { signal: AbortSignal.timeout(3500), credentials: 'same-origin' }).then(r => { if (!r.ok || !r.headers.get('content-type')?.includes('application/json')) throw new Error(); return r.json(); }).then(config => { runtime.assistant = config.assistant === 'ai' ? 'ai' : 'local'; runtime.contact = ['email', 'mailto'].includes(config.contact) ? config.contact : (data.profile.email ? 'mailto' : 'draft'); contactPresentation(); chatPresentation(); }).catch(() => { /* Static hosting intentionally stays in transparent local/draft modes. */ });
  }
  // Project card depth is pointer-only and removed when motion is reduced.
  $$('[data-tilt]').forEach(card => {
    let frame = 0, targetX = 0, targetY = 0, x = 0, y = 0;
    function animate() { frame = 0; x += (targetX - x) * .14; y += (targetY - y) * .14; card.style.transform = `perspective(1200px) rotateX(${x.toFixed(3)}deg) rotateY(${y.toFixed(3)}deg)`; if (Math.abs(targetX - x) + Math.abs(targetY - y) > .015) frame = requestAnimationFrame(animate); else if (!targetX && !targetY) card.style.transform = ''; }
    function tick() { if (!frame) frame = requestAnimationFrame(animate); }
    card.addEventListener('pointermove', event => { if (reduced() || event.pointerType !== 'mouse') return; const r = card.getBoundingClientRect(); targetX = -((event.clientY - r.top) / r.height - .5) * 3.3; targetY = ((event.clientX - r.left) / r.width - .5) * 3.3; tick(); }, { passive: true });
    card.addEventListener('pointerleave', () => { targetX = 0; targetY = 0; tick(); }, { passive: true });
    media.addEventListener('change', () => { if (reduced()) { cancelAnimationFrame(frame); frame = 0; targetX = targetY = x = y = 0; card.style.transform = ''; } });
  });
  // Cursor particles are finite, subtle, and never intercept a click or scroll.
  (function particles() {
    const canvas = $('#cursor-particles'), ctx = canvas.getContext('2d'); if (!ctx) return;
    let list = [], frame = 0, lastSpawn = 0, limit = 22, color = '#246a55', lastTime = 0;
    function size() { const dpr = Math.min(devicePixelRatio || 1, 1.5); canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); color = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim(); }
    function draw(now) { frame = 0; const dt = Math.min((now - (lastTime || now)) / 16.67, 2.5); lastTime = now; ctx.clearRect(0, 0, innerWidth, innerHeight); list = list.filter(p => now - p.start < 650); for (const p of list) { p.x += p.vx * dt; p.y += p.vy * dt; const life = 1 - (now - p.start) / 650; ctx.globalAlpha = Math.max(0, life) * .28; ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, p.radius * Math.max(.2, life), 0, Math.PI * 2); ctx.fill(); } ctx.globalAlpha = 1; if (list.length && !document.hidden && !reduced()) frame = requestAnimationFrame(draw); }
    function spawn(event) { if (reduced() || document.hidden || navigator.connection?.saveData || !event.isPrimary) return; const now = performance.now(); if (now - lastSpawn < 35) return; lastSpawn = now; if (list.length >= limit) list.shift(); list.push({ x: event.clientX, y: event.clientY, vx: (Math.random() - .5) * .3, vy: -.35 - Math.random() * .2, radius: 1 + Math.random() * 1.2, start: now }); if (!frame) { lastTime = now; frame = requestAnimationFrame(draw); } }
    size(); window.addEventListener('resize', size, { passive: true }); window.addEventListener('portfolio-theme', size); window.addEventListener('pointermove', spawn, { passive: true }); window.addEventListener('pointerdown', spawn, { passive: true }); window.addEventListener('portfolio-quality', () => { limit = 8; });
    function stop() { cancelAnimationFrame(frame); frame = 0; list = []; ctx.clearRect(0, 0, innerWidth, innerHeight); }
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); }); media.addEventListener('change', stop);
  })();
  // The page never waits for a 3D asset to become usable.
  $('#loader-progress').style.width = '75%';
  const finishLoading = () => { $('#loader-progress').style.width = '100%'; setTimeout(() => $('#loader').classList.add('complete'), reduced() ? 0 : 260); };
  if (document.readyState === 'complete') finishLoading(); else window.addEventListener('load', finishLoading, { once: true });
  setTimeout(finishLoading, 1400);
  const launch3D = () => { if (window.PortfolioName3D) window.PortfolioName3D.init(data.profile.name); };
  if ('requestIdleCallback' in window) requestIdleCallback(launch3D, { timeout: 1800 }); else setTimeout(launch3D, 900);
  window.PortfolioApp = Object.freeze({ data, filterExperience, openChat, getMode: () => ({ ...runtime }) });
})();
