/* A small real WebGL renderer for a baked extruded name.
   Geometry has front/back faces, bevels and walls. No font is shipped.
   This renderer is an intentional zero-dependency alternative to Three.js. */
(function (root) {
  'use strict';
  const vertex = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;
    uniform mat4 uMVP;
    uniform mat4 uModel;
    uniform mat3 uRotation;
    varying vec3 vNormal;
    varying vec3 vPosition;
    void main() {
      vNormal = normalize(uRotation * aNormal);
      vPosition = (uModel * vec4(aPosition, 1.0)).xyz;
      gl_Position = uMVP * vec4(aPosition, 1.0);
    }`;
  const fragment = `
    precision mediump float;
    varying vec3 vNormal;
    varying vec3 vPosition;
    uniform float uDark;
    void main() {
      vec3 N = normalize(vNormal);
      vec3 V = normalize(-vPosition);
      vec3 L = normalize(vec3(-1.1, 1.8, 2.3));
      vec3 F = normalize(vec3(1.4, -0.1, 1.2));
      float diffuse = max(dot(N,L), 0.0);
      float sideFill = max(dot(N,F), 0.0);
      float specular = pow(max(dot(N,normalize(L+V)),0.0), 82.0);
      float fineSpecular = pow(max(dot(N,normalize(F+V)),0.0), 132.0);
      float facing = max(dot(N,V),0.0);
      float fresnel = .035 + .65 * pow(1.0-facing, 4.0);
      vec3 reflection = reflect(-V,N);
      float room = .04 + .16 * smoothstep(-.4,.85,reflection.y);
      float strip = pow(max(0.0,1.0-abs(reflection.y-.48)*3.0),12.0);
      vec3 base = mix(vec3(.018,.025,.019), vec3(.49,.56,.48), uDark);
      vec3 color = base * (.42 + .66 * diffuse + .15 * sideFill);
      color += vec3(room) * (.14 + fresnel);
      color += vec3(.87,.93,.87) * (specular*.65 + fineSpecular*.4 + strip*.11);
      color += vec3(.02,.038,.022) * pow(1.0-facing,2.0);
      color = pow(clamp(color,0.0,1.0),vec3(1.0/2.2));
      gl_FragColor = vec4(color,1.0);
    }`;
  function multiply(a,b) { const out = new Float32Array(16); for(let c=0;c<4;c++) for(let r=0;r<4;r++) for(let k=0;k<4;k++) out[c*4+r] += a[k*4+r]*b[c*4+k]; return out; }
  const identity = () => new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
  function rotation(x,y) { const cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y); const rx=new Float32Array([1,0,0,0,0,cx,sx,0,0,-sx,cx,0,0,0,0,1]); const ry=new Float32Array([cy,0,-sy,0,0,1,0,0,sy,0,cy,0,0,0,0,1]); return multiply(ry,rx); }
  function perspective(aspect) { const f=1/Math.tan(.49/2), near=.1, far=20; return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,(2*far*near)/(near-far),0]); }
  function decode(value) { return Uint8Array.from(atob(value), c=>c.charCodeAt(0)); }
  function init(expectedName) {
    const stage = document.getElementById('name-stage'), canvas = document.getElementById('name-canvas');
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    if (stage) stage.dataset.renderMode = '2d';
    if (!stage || !canvas || motion.matches || navigator.connection?.saveData || (navigator.deviceMemory && navigator.deviceMemory < 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4)) return;
    let mesh;
    try { mesh=JSON.parse(document.getElementById('name-mesh-data').textContent); } catch { return; }
    if (mesh.name !== expectedName) return;
    let gl, program, active=true, visible=true, frame=0, ready=false, dpr=Math.min(devicePixelRatio||1,1.6), targetX=.06, targetY=-.085, x=.06, y=-.085, last=0, samples=[], downgrades=0;
    const cleanup=[];
    try {
      gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:false,powerPreference:'low-power',preserveDrawingBuffer:false});
      if (!gl) return;
      function compile(type,source) { const s=gl.createShader(type); gl.shaderSource(s,source); gl.compileShader(s); if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){gl.deleteShader(s);throw new Error('Shader unavailable');} return s; }
      const vs=compile(gl.VERTEX_SHADER,vertex),fs=compile(gl.FRAGMENT_SHADER,fragment); program=gl.createProgram(); gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error('WebGL unavailable');gl.useProgram(program);
      const positions=gl.createBuffer(),normals=gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER,positions);gl.bufferData(gl.ARRAY_BUFFER,decode(mesh.positions),gl.STATIC_DRAW);const pa=gl.getAttribLocation(program,'aPosition');gl.enableVertexAttribArray(pa);gl.vertexAttribPointer(pa,3,gl.SHORT,true,0,0);
      gl.bindBuffer(gl.ARRAY_BUFFER,normals);gl.bufferData(gl.ARRAY_BUFFER,decode(mesh.normals),gl.STATIC_DRAW);const na=gl.getAttribLocation(program,'aNormal');gl.enableVertexAttribArray(na);gl.vertexAttribPointer(na,3,gl.BYTE,true,0,0);
      const mvpLoc=gl.getUniformLocation(program,'uMVP'),modelLoc=gl.getUniformLocation(program,'uModel'),rotationLoc=gl.getUniformLocation(program,'uRotation'),darkLoc=gl.getUniformLocation(program,'uDark');
      gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(0,0,0,0);
      function draw() {
        if (!active || !visible || document.hidden || motion.matches || !stage.clientWidth) return;
        const w=stage.clientWidth,h=stage.clientHeight,pw=Math.max(1,Math.round(w*dpr)),ph=Math.max(1,Math.round(h*dpr));
        if(canvas.width!==pw||canvas.height!==ph){canvas.width=pw;canvas.height=ph;gl.viewport(0,0,pw,ph);}
        const aspect=w/h,projection=perspective(aspect),cam=4,f=projection[5];
        const scale=Math.min(2*.97*aspect*cam/(f*mesh.width),2*.70*cam/(f*mesh.height));
        const rot=rotation(x,y),model=new Float32Array(rot);for(let i=0;i<12;i++)model[i]*=scale;model[12]=-.015;model[13]=0;model[14]=-cam;
        gl.uniformMatrix4fv(mvpLoc,false,multiply(projection,model));gl.uniformMatrix4fv(modelLoc,false,model);gl.uniformMatrix3fv(rotationLoc,false,new Float32Array([rot[0],rot[1],rot[2],rot[4],rot[5],rot[6],rot[8],rot[9],rot[10]]));gl.uniform1f(darkLoc,document.documentElement.dataset.theme==='dark'?1:0);
        gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.drawArrays(gl.TRIANGLES,0,mesh.vertexCount);
        if(!ready){stage.classList.add('has-3d');ready=true;stage.dataset.renderMode='webgl';}
      }
      function animate(now) {
        frame=0;if(!active||!visible||document.hidden)return;
        if(last){const dt=now-last;if(dt<200)samples.push(dt);}last=now;
        if(samples.length>=65){const avg=samples.reduce((a,b)=>a+b,0)/samples.length;samples=[];if(avg>28){if(downgrades>=2){dispose();return;}dpr=Math.max(.75,dpr*.72);downgrades++;window.dispatchEvent(new CustomEvent('portfolio-quality',{detail:{quality:dpr}}));}}
        x+=(targetX-x)*.1;y+=(targetY-y)*.1;draw();
        if(Math.abs(targetX-x)+Math.abs(targetY-y)>.00012)frame=requestAnimationFrame(animate);else last=0;
      }
      function wake(){if(!frame&&active&&visible&&!document.hidden)frame=requestAnimationFrame(animate);}
      function point(event){if(!active||!visible||motion.matches)return;const r=stage.getBoundingClientRect();targetX=.045-(Math.max(-1,Math.min(1,(event.clientY-r.top-r.height/2)/320)))*.06;targetY=-.055+(Math.max(-1,Math.min(1,(event.clientX-r.left-r.width/2)/(r.width/2))))*.09;wake();}
      function dispose(){if(!active)return;active=false;cancelAnimationFrame(frame);frame=0;stage.classList.remove('has-3d');stage.dataset.renderMode='2d';try{gl.deleteBuffer(positions);gl.deleteBuffer(normals);gl.deleteProgram(program);gl.getExtension('WEBGL_lose_context')?.loseContext();}catch{}cleanup.forEach(fn=>fn());}
      function on(target,event,fn,options){target.addEventListener(event,fn,options);cleanup.push(()=>target.removeEventListener(event,fn,options));}
      on(window,'pointermove',point,{passive:true});on(window,'pointerdown',point,{passive:true});on(window,'resize',()=>draw(),{passive:true});on(window,'portfolio-theme',()=>draw());on(canvas,'webglcontextlost',()=>{active=false;stage.classList.remove('has-3d');stage.dataset.renderMode='2d';cancelAnimationFrame(frame);cleanup.forEach(fn=>fn());});on(document,'visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;last=0;}else{draw();wake();}});on(motion,'change',()=>{if(motion.matches)dispose();});
      if('IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible){draw();wake();}else{cancelAnimationFrame(frame);frame=0;last=0;}},{threshold:0});observer.observe(stage);cleanup.push(()=>observer.disconnect());}
      if(navigator.getBattery)navigator.getBattery().then(battery=>{if(!battery.charging&&battery.level<.15)dispose();}).catch(()=>{});
      draw();
    } catch { stage.classList.remove('has-3d');stage.dataset.renderMode='2d';active=false;cancelAnimationFrame(frame);try{if(program)gl.deleteProgram(program);}catch{}cleanup.forEach(fn=>fn()); }
  }
  root.PortfolioName3D=Object.freeze({init});
})(globalThis);
