/* Shared by the browser and API. Local answers never masquerade as generative AI. */
(function (root) {
  'use strict';
  const normalize = value => String(value || '').toLowerCase().normalize('NFKC').replace(/\s+/g, ' ').trim();
  const topics = /\b(profil|portofolio|portfolio|pengalaman|kerja|karier|career|cultivia|kebun|tanaman|petani|destilasi|ternak|peternakan|little|tiam|barista|kitchen|kapten|waiters|burjo|j&t|logistik|sortir|paket|freelance|sekolah|pendidikan|smk|smp|sd|kuliah|ipk|skill|keahlian|kemampuan|coding|pemrograman|html|css|javascript|python|three|ai|web|belajar|karya|project|proyek|kontak|email|hubungi|nomor|telepon|whatsapp|wa|tiktok|tt|sosial|sosmed|cv|resume|nama|panggilan|nickname|siapa|domisili|alamat|dokumentasi|keuangan|kas|gaji|sertifikat|umur|usia|hobi)\b/i;
  const greeting = /^(halo|hai|hi|hello|hey|selamat (pagi|siang|sore|malam)|terima kasih|makasih|thanks)[!.? ]*$/i;
  function isPortfolioQuestion(question, data) {
    const q = normalize(question);
    return topics.test(q) || greeting.test(q) || q.includes(normalize(data.profile.name)) || Boolean(data.profile.fullName && q.includes(normalize(data.profile.fullName)));
  }
  function localAnswer(question, data) {
    const q = normalize(question), p = data.profile;
    if (greeting.test(q)) return `Halo! Aku asisten profil ${p.name}. Dalam mode lokal, aku menggunakan jawaban dari data portofolio, bukan AI generatif. Kamu bisa bertanya tentang pengalaman kerja, skill, pendidikan, atau karya.`;
    if (/\b(abaikan|ignore|bocorkan|system prompt|api key|kunci api)\b/.test(q)) return 'Aku hanya membantu menjelaskan isi portofolio. Untuk keperluan lain, silakan gunakan bagian Kontak.';
    if (/\b(kontak|email|hubungi|nomor|telepon|whatsapp|wa|tiktok|tt|sosial|sosmed|alamat|domisili|cv|resume)\b/.test(q)) {
      const items = [];
      if (/\b(cv|resume)\b/.test(q)) items.push(`CV bisa diunduh melalui tombol di bagian Beranda.${p.cvIsDraft ? ' File masih berlabel draf berdasarkan PRD; identitas dan kontak sudah diperbarui. Periksa seluruh isinya sebelum dipakai melamar.' : ''}`);
      items.push(p.email ? `Email: ${p.email}.` : 'Alamat email pemilik belum dicantumkan. Form Kontak saat ini dapat dipakai untuk menyiapkan draf, bukan mengirim email.');
      if (p.socials?.whatsapp) items.push(`WhatsApp: ${p.phoneDisplay || p.phone || p.socials.whatsapp}. Tautan: ${p.socials.whatsapp}`);
      if (p.socials?.tiktok) items.push(`TikTok: ${p.socials.tiktok}`);
      if (/\b(domisili|alamat)\b/.test(q)) items.push(p.location ? `Domisili: ${p.location}.` : 'Domisili belum dicantumkan; lokasi sekolah tidak dipakai untuk menyimpulkan tempat tinggal.');
      return items.join('\n\n');
    }
    if (/\b(umur|usia|lahir|gaji|hobi|sertifikat|ipk|kuliah)\b/.test(q)) return 'Informasi itu belum dicantumkan dalam data portofolio. Aku tidak akan menebaknya. Data pendidikan yang tersedia adalah SD, SMP, dan SMK; informasi lain dapat ditanyakan melalui bagian Kontak.';
    if (/\b(pendidikan|sekolah|smk|smp|sd|lulus)\b/.test(q)) return `Riwayat pendidikan ${p.name}:\n\n${data.education.map(s => `${s.school} (${s.period}).`).join('\n')}\n\nJurusan, IPK, dan pendidikan lain belum dicantumkan.`;
    if (/\b(catatan|dokumentasi|dokumenter)\b/.test(q) && /\b(project|proyek|karya|contoh|format|studi|catatan)\b/.test(q)) return 'Catatan Progres Harian Kebun adalah studi kasus pekerjaan, bukan aplikasi. Tugasnya merekam kegiatan petani, mencatat tanaman, hasil panen, serta ketercapaian target, kemudian mengirim ringkasan kepada HRD atau kepala cabang.\n\nDi bagian Karya tersedia contoh format kosong. Foto dan data asli Cultivia tidak ditampilkan tanpa izin; hasil kuantitatif belum tersedia.';
    if (/\b(little|tiam|barista|kitchen|kapten)\b/.test(q)) return 'Di Little Tiam (September 2024 - Juli 2025), progres role yang dicatat adalah waiters, barista, kitchen, lalu wakil kapten divisi barista dan kitchen dalam kurang dari satu tahun. Sempat ditawari posisi kapten, tetapi sudah resign. Jadi, jabatan kapten tidak diklaim sebagai posisi yang pernah dijalani.';
    if (/\b(cultivia|kebun|tanaman|petani|destilasi|peternakan|ternak|keuangan|kas)\b/.test(q)) {
      if (/\b(keuangan|kas|laporan)\b/.test(q)) return 'Di Cultivia, tugas asisten keuangan adalah mencatat pemasukan dan pengeluaran aktual kebun secara harian dan bulanan. Ini bukan penyusunan laporan keuangan formal. Kemampuan akuntansi profesional tidak diklaim.';
      return 'Sebagai Staff Kebun di Cultivia sejak Juli 2025, ada tujuh lingkup tanggung jawab: perawatan tanaman, operator destilasi minyak atsiri, dokumentasi progres harian, belanja kebutuhan, pencatatan kas aktual, sensus dan pengukuran parameter tanaman, serta peternakan.\n\nRincian setiap tugas bisa dibuka pada kartu Cultivia di bagian Pengalaman.';
    }
    if (q.includes('j&t') || /\b(sortir|paket|logistik)\b/.test(q)) return 'Pengalaman freelance sortir paket di J&T berlangsung Februari - Desember 2024. Pekerjaan ini dijalani saat libur sekolah dan libur panjang sebelum lulus SMK. Data tentang volume paket atau pencapaian numerik tidak dicantumkan.';
    if (/\b(burjo|pandemi)\b/.test(q)) return 'Pada Mei - Agustus 2021, bekerja sebagai freelance waiters di warung makan (Burjo). Saat sekolah libur di masa pandemi, shift malam dijalani sambil tetap belajar daring pada pagi hari.';
    if (/\b(skill|kemampuan|keahlian|coding|pemrograman|html|css|javascript|python|three|expert|ahli)\b/.test(q)) return 'Skill teknis yang tercantum: HTML, CSS, JavaScript, Python, dan Three.js, semuanya di level dasar. Web dan AI mulai dipelajari sejak Februari 2026; belum expert.\n\nPengalaman kerja juga mencakup dokumentasi, pelayanan pelanggan, kerja tim, pencatatan kas aktual, dan operasional kebun. Tidak ada persentase kemampuan atau sertifikasi yang dibuat-buat.';
    if (/\b(tahun|sejak|lama)\b/.test(q) && /\b(web|ai|pengalaman|kerja|belajar)\b/.test(q)) return 'Penulisannya sengaja dipisah: bekerja sejak 2021, sedangkan web development dan AI mulai dipelajari sejak Februari 2026. Pengalaman kerja mencakup periode freelance dan karyawan; bukan lima tahun kerja terus-menerus, dan bukan lima tahun sebagai web developer.';
    if (/\b(pengalaman|kerja|karier|career|freelance)\b/.test(q)) return `Perjalanan ${p.name}, dari terbaru:\n\n1. Web Developer & AI Founder, tahap awal belajar (Februari 2026 - sekarang).\n2. Staff Kebun, Cultivia (Juli 2025 - sekarang).\n3. Crew Rumah Makan, Little Tiam (September 2024 - Juli 2025).\n4. Freelance sortir paket, J&T (Februari - Desember 2024).\n5. Freelance waiters, Burjo (Mei - Agustus 2021).\n\nBagian Pengalaman menyediakan filter dan rincian tanggung jawab.`;
    if (/\b(karya|project|proyek|portofolio|portfolio)\b/.test(q)) return 'Ada dua entri Karya Terpilih: Website Portofolio Ini (project web, masih tahap pratinjau/dalam pengerjaan) dan Catatan Progres Harian Kebun (studi kasus pekerjaan di Cultivia, bukan aplikasi).\n\nKeduanya memiliki tombol detail. Tidak ada project tambahan, tautan repository palsu, atau dokumentasi internal yang dipublikasikan.';
    if (/\b(web|ai|belajar)\b/.test(q)) return `${p.name} mulai mengenal dan menikmati web development serta AI sejak Februari 2026. Peran "Web Developer & AI Founder" mengikuti PRD, dengan penjelasan bahwa prosesnya masih tahap awal. Dasar HTML, CSS, JavaScript, Python, serta Three.js sedang dipelajari dan telah dipakai dalam project kecil, termasuk portofolio.`;
    if (/\b(profil|siapa|nama|kenalan|panggilan|nickname)\b/.test(q) || q.includes(normalize(p.name)) || Boolean(p.fullName && q.includes(normalize(p.fullName)))) return `${p.fullName ? p.fullName + ', biasa dipanggil ' + p.name : p.name}${p.displayNameIsPlaceholder ? ' (nama tampilan sementara)' : ''}. Pengalaman kerjanya mencakup kebun, F&B, serta logistik. Sejak Februari 2026, mulai belajar web development dan AI dari dasar.\n\nAku bisa menjelaskan pengalaman, pendidikan, skill, dan karya yang tercantum.`;
    return 'Aku hanya punya informasi seputar profil, pengalaman, pendidikan, skill, dan karya di portofolio ini. Informasi yang kamu tanyakan belum tersedia atau berada di luar cakupan. Untuk keperluan lain, silakan menuju bagian Kontak.';
  }
  root.PortfolioAssistant = Object.freeze({ normalize, localAnswer, isPortfolioQuestion });
})(globalThis);
