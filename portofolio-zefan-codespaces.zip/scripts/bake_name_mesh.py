"""Bake only the display-name mesh, not a font, into the deliverable."""
from pathlib import Path
import base64, json, math
import numpy as np
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from shapely.geometry import Polygon, GeometryCollection
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles, make_valid

import argparse
parser = argparse.ArgumentParser(description='Bake the portfolio display name using a local font.')
parser.add_argument('--font', required=True, help='Path to a font you are licensed to use locally')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
name = json.loads((root / 'content/portfolio.json').read_text())['profile']['name']
font = args.font
if not Path(font).is_file():
    raise SystemExit('Font file not found. Supply a local font with --font.')
path = TextPath((0, 0), name + '.', size=1, prop=FontProperties(fname=font))
shape = GeometryCollection()
for arr in path.to_polygons():
    poly = make_valid(Polygon(arr))
    if poly.area > 1e-6:
        shape = shape.symmetric_difference(poly)
if not shape.is_valid:
    shape = make_valid(shape)
polys = [shape] if shape.geom_type == 'Polygon' else [p for p in shape.geoms if p.geom_type == 'Polygon']
minx, miny, maxx, maxy = shape.bounds
cx, cy = (maxx + minx) / 2, (maxy + miny) / 2
positions, normals = [], []
depth, bevel = .078, .005

def triangle(points, ns):
    positions.extend(points)
    normals.extend(ns)

def rings_for(poly):
    poly = orient(poly, sign=1.0)
    return [np.asarray(poly.exterior.coords[:-1], dtype=float)] + [np.asarray(r.coords[:-1], dtype=float) for r in poly.interiors]

def inset(ring):
    n = len(ring)
    out, ns = [], []
    for i, p in enumerate(ring):
        a, b = p - ring[(i-1) % n], ring[(i+1) % n] - p
        a /= max(np.linalg.norm(a), 1e-12)
        b /= max(np.linalg.norm(b), 1e-12)
        n1, n2 = np.array([a[1], -a[0]]), np.array([b[1], -b[0]])
        normal = n1 + n2
        normal /= max(np.linalg.norm(normal), 1e-12)
        distance = min(bevel / max(np.dot(normal, n1), .15), bevel * 2.5)
        out.append(p - normal * distance)
        ns.append(normal)
    return np.asarray(out), np.asarray(ns)

for poly in polys:
    rings = rings_for(poly)
    inners, ring_normals = [], []
    for ring in rings:
        ins, ns = inset(ring)
        inners.append(ins)
        ring_normals.append(ns)
    front_shape = make_valid(Polygon(inners[0], inners[1:]))
    front_polys = [front_shape] if front_shape.geom_type == 'Polygon' else [p for p in front_shape.geoms if p.geom_type == 'Polygon']
    for fpoly in front_polys:
        for tri in constrained_delaunay_triangles(fpoly).geoms:
            pts = list(orient(tri, sign=1.0).exterior.coords)[:3]
            triangle([(x, y, depth/2) for x, y in pts], [(0,0,1)]*3)
            triangle([(x, y, -depth/2) for x, y in pts[::-1]], [(0,0,-1)]*3)
    for ring, inner, ns in zip(rings, inners, ring_normals):
        layers = [(inner, -depth/2), (ring, -depth/2 + bevel), (ring, depth/2-bevel), (inner, depth/2)]
        for layer_index in range(3):
            p0, z0 = layers[layer_index]
            p1, z1 = layers[layer_index+1]
            for i in range(len(ring)):
                j = (i+1) % len(ring)
                a, b = (*p0[i], z0), (*p0[j], z0)
                c, d = (*p1[j], z1), (*p1[i], z1)
                znormal = -1 if layer_index == 0 else 1 if layer_index == 2 else 0
                ni = np.array([*ns[i], znormal], float); nj = np.array([*ns[j], znormal], float)
                ni /= np.linalg.norm(ni); nj /= np.linalg.norm(nj)
                triangle([a,b,d], [ni,nj,ni])
                triangle([b,c,d], [nj,nj,ni])
arr = np.asarray(positions, dtype=float)
arr[:,0] -= cx
arr[:,1] -= cy
scale = max(np.abs(arr).max(), 1)
encoded_positions = np.round(arr / scale * 30000).astype('<i2')
encoded_normals = np.round(np.asarray(normals)*126).astype('i1')
mesh = {
    'name': name,
    'description': 'Baked extruded display-name mesh; no font file included.',
    'vertexCount': len(arr),
    'width': (maxx-minx)/scale*30000/32767,
    'height': (maxy-miny)/scale*30000/32767,
    'positions': base64.b64encode(encoded_positions.tobytes()).decode('ascii'),
    'normals': base64.b64encode(encoded_normals.tobytes()).decode('ascii')
}
(root/'public/assets/name-mesh.json').write_text(json.dumps(mesh,separators=(',',':')))
print('mesh:', len(arr), 'vertices;', (root/'public/assets/name-mesh.json').stat().st_size, 'bytes; name', name)
