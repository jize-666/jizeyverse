"""Regenerate the two-page draft CV from portfolio.json. No font files are shipped.
Optional dependencies: pip install reportlab pillow
Run this script before npm run build after changing profile/CV content.
"""
from pathlib import Path
from io import BytesIO
from xml.sax.saxutils import escape
import json
from PIL import Image as PILImage, ImageOps
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'content/portfolio.json').read_text())
PROFILE = DATA['profile']
OUTPUT = ROOT / 'public' / PROFILE['cv']
INK = colors.HexColor('#202824')
MUTED = colors.HexColor('#68716b')
ACCENT = colors.HexColor('#246a55')
LINE = colors.HexColor('#dfe4de')
styles = {
    'name': ParagraphStyle('name', fontName='Helvetica-Bold', fontSize=26, leading=29, textColor=INK, spaceAfter=7),
    'pageTitle': ParagraphStyle('pageTitle', fontName='Helvetica-Bold', fontSize=23, leading=28, textColor=INK, spaceAfter=17),
    'eyebrow': ParagraphStyle('eyebrow', fontName='Helvetica', fontSize=8, leading=12, textColor=MUTED, spaceAfter=8),
    'heading': ParagraphStyle('heading', fontName='Helvetica-Bold', fontSize=11, leading=16, textColor=ACCENT, spaceBefore=15, spaceAfter=8, keepWithNext=True),
    'role': ParagraphStyle('role', fontName='Helvetica-Bold', fontSize=11.5, leading=16, textColor=INK, spaceBefore=9, spaceAfter=3, keepWithNext=True),
    'body': ParagraphStyle('body', fontName='Helvetica', fontSize=9.7, leading=14.2, textColor=INK, spaceAfter=6),
    'small': ParagraphStyle('small', fontName='Helvetica', fontSize=8.5, leading=12, textColor=MUTED, spaceAfter=5),
    'contact': ParagraphStyle('contact', fontName='Helvetica', fontSize=9, leading=14, textColor=INK, spaceAfter=3),
}
def para(text, kind='body'):
    return Paragraph(text, styles[kind])
def safe(text):
    return escape(str(text))
def heading(text):
    return para(text, 'heading')
MONTHS = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des']
def date_label(value):
    if value == 'present':
        return 'sekarang'
    year, month = value.split('-')
    return f'{MONTHS[int(month)-1]} {year}'
def experience_header(item):
    return [para(f'{safe(item["role"])} | {safe(item["organization"])}', 'role'), para(f'{date_label(item["start"])} - {date_label(item["end"])} | {safe(item["type"])}', 'small')]

def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.line(42, 40, A4[0]-42, 40)
    canvas.setFillColor(MUTED)
    canvas.setFont('Helvetica', 7.5)
    canvas.drawString(42, 27, 'DRAF | Konten dari PRD; identitas dan kontak diperbarui oleh pemilik.')
    canvas.drawRightString(A4[0]-42, 27, f'{doc.page} / 2')
    canvas.restoreState()

text_header = [
    para('CURRICULUM VITAE / DRAF', 'eyebrow'),
    para(safe(PROFILE.get('fullName') or PROFILE['name']), 'name'),
    para(f'Dipanggil <b>{safe(PROFILE["name"])}</b> | Pengalaman lintas bidang', 'small'),
    para(f'<link href="mailto:{safe(PROFILE["email"])}" color="#246a55">{safe(PROFILE["email"])}</link>', 'contact'),
    para(f'WhatsApp: <link href="{safe(PROFILE["socials"]["whatsapp"])}" color="#246a55">{safe(PROFILE.get("phoneDisplay") or PROFILE["phone"])}</link>', 'contact'),
    para(f'TikTok: <link href="{safe(PROFILE["socials"]["tiktok"])}" color="#246a55">{safe(PROFILE["socials"]["tiktok"].split("/")[-1])}</link>', 'contact'),
]
photo = PILImage.open(ROOT/'public'/PROFILE['portrait']).convert('RGB')
photo = ImageOps.fit(photo, (400, 496), centering=(0.5,0.33))
photo_buf = BytesIO()
photo.save(photo_buf, 'JPEG', quality=90)
photo_buf.seek(0)
head = Table([[text_header, Image(photo_buf, 100, 124)]], colWidths=[A4[0]-84-120,120])
head.setStyle(TableStyle([
    ('VALIGN',(0,0),(-1,-1),'TOP'),
    ('LEFTPADDING',(0,0),(0,-1),0),('RIGHTPADDING',(0,0),(0,-1),20),
    ('TOPPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),8),
    ('ALIGN',(1,0),(1,-1),'RIGHT'),('RIGHTPADDING',(1,0),(1,-1),0),
]))
story = [head, heading('PROFIL')]
story.append(para('Berpengalaman di pekerjaan kebun, F&amp;B, dan logistik. Mulai belajar web development dan AI sejak Februari 2026. Bekerja sejak 2021 mencakup beberapa periode freelance dan karyawan, bukan pengalaman kerja terus-menerus dan bukan lima tahun sebagai web developer.'))
story.append(heading('PENGALAMAN TERBARU'))
web, garden, *others = DATA['experience']
story.extend(experience_header(web))
for h in web['highlights']:
    story.append(para('- '+safe(h)))
story.extend(experience_header(garden))
story.append(para('Satu posisi dengan beragam tanggung jawab:'))
for item in garden['responsibilities']:
    story.append(para(f'<b>{safe(item["title"])}.</b> {safe(item["description"])}'))

story.append(PageBreak())
story.extend([para('CURRICULUM VITAE / '+safe(PROFILE['name']).upper(), 'eyebrow'), para('Pengalaman &amp; pendidikan', 'pageTitle')])
for item in others:
    section = experience_header(item)
    if item['highlights']:
        section.extend(para('- '+safe(h)) for h in item['highlights'])
    else:
        section.append(para(safe(item['description'])))
    story.append(KeepTogether(section))

story.append(heading('PENDIDIKAN'))
for item in DATA['education']:
    story.append(para(f'<b>{safe(item["school"])}</b> | {safe(item["period"])}'))
story.append(heading('KEMAMPUAN'))
story.append(para('<b>Teknis / dasar:</b> HTML, CSS, JavaScript, Python, dan Three.js. Eksplorasi web dan AI masih tahap awal; belum expert.'))
story.append(para('<b>Dari praktik kerja:</b> dokumentasi, pelayanan pelanggan, kerja tim, pencatatan kas aktual, pengadaan kebutuhan, serta operasional kebun.'))
story.append(heading('KARYA TERPILIH'))
story.append(para('<b>Website Portofolio Ini.</b> Project web, versi pratinjau / dalam pengerjaan.'))
story.append(para('<b>Catatan Progres Harian Kebun.</b> Studi kasus pekerjaan terkait dokumentasi di Cultivia, bukan aplikasi. Foto dan data internal memerlukan izin; contoh publik berupa format kosong.'))

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
doc = SimpleDocTemplate(str(OUTPUT), pagesize=A4, leftMargin=42, rightMargin=42, topMargin=38, bottomMargin=55,
    title=f'CV Draf - {PROFILE.get("fullName") or PROFILE["name"]}', author=PROFILE.get('fullName') or PROFILE['name'],
    subject='Pengalaman kerja, pendidikan, dan keterampilan berdasarkan PRD serta identitas dari pemilik.')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUTPUT)
