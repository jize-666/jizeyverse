import { readFile, writeFile, mkdir, cp, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve, join, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { renderPage, escapeHTML } from '../src/render.mjs';
import { paths } from '../src/icons.mjs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const boot = `try{document.documentElement.dataset.theme=localStorage.getItem('portfolio-theme')==='dark'?'dark':'light'}catch(e){document.documentElement.dataset.theme='light'}`;
const safeJSON = obj => JSON.stringify(obj).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
const hash = value => createHash('sha256').update(value).digest('base64');
export async function build() {
  const data = JSON.parse(await readFile(join(root, 'content/portfolio.json'), 'utf8'));
  if (!data.profile?.name || !Array.isArray(data.experience) || !Array.isArray(data.projects)) throw new Error('Data profil, pengalaman, dan karya wajib tersedia.');
  const dist = join(root, 'dist'); await rm(dist, { recursive: true, force: true }); await mkdir(dist, { recursive: true }); await cp(join(root, 'public'), dist, { recursive: true }); await mkdir(join(dist, 'assets'), { recursive: true });
  for (const file of ['styles.css', 'assistant.js', 'name-3d.js', 'app.js']) await cp(join(root, 'src', file), join(dist, 'assets', file));
  let mesh = {};
  try { mesh = JSON.parse(await readFile(join(root, 'public/assets/name-mesh.json'), 'utf8')); } catch { /* The 2D name is always available. */ }
  let siteURL = '';
  try { const raw = process.env.SITE_URL || data.site.url; if (raw) { const parsed = new URL(raw); if (parsed.protocol === 'https:' && !parsed.username && !parsed.password) siteURL = parsed.origin; } } catch { /* No fabricated canonical URL. */ }
  const indexed = Boolean(data.site.allowIndexing && !data.profile.displayNameIsPlaceholder && siteURL);
  const title = escapeHTML(`${data.profile.name} - Portofolio Pribadi`), description = escapeHTML(data.site.description);
  const favicon = 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#222b26"/><text x="13" y="46" font-family="Arial,sans-serif" font-size="46" font-weight="bold" fill="#f8f9f7">${escapeHTML((data.profile.initial || data.profile.name[0]).toLowerCase())}.</text></svg>`);
  const head = `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#f8f9f7"><title>${title}</title><meta name="description" content="${description}"><meta name="robots" content="${indexed ? 'index,follow' : 'noindex,nofollow'}"><meta property="og:type" content="website"><meta property="og:locale" content="id_ID"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta name="twitter:card" content="summary_large_image">${siteURL ? `<link rel="canonical" href="${siteURL}/"><meta property="og:url" content="${siteURL}/"><meta property="og:image" content="${siteURL}/assets/og-cover.webp">` : ''}<meta name="author" content="${escapeHTML(data.profile.fullName || data.profile.name)}"><link rel="icon" href="${favicon}"><script>${boot}</script>`;
  const body = renderPage(data);
  const jsonBlocks = `<script id="portfolio-data" type="application/json">${safeJSON(data)}</script><script id="icon-data" type="application/json">${safeJSON(paths)}</script><script id="name-mesh-data" type="application/json">${safeJSON(mesh)}</script>`;
  const css = await readFile(join(root, 'src/styles.css'), 'utf8');
  const noScript = '<noscript><style>.loader{display:none!important}.reveal{opacity:1!important;transform:none!important}.contact-form .form-submit{display:none}</style></noscript>';
  const html = `<!doctype html>\n<html lang="id" data-theme="light"><head>${head}<link rel="stylesheet" href="assets/styles.css">${noScript}</head><body>${body}${jsonBlocks}<script src="assets/assistant.js" defer></script><script src="assets/name-3d.js" defer></script><script src="assets/app.js" defer></script></body></html>`;
  await writeFile(join(dist, 'index.html'), html);
  await writeFile(join(dist, 'robots.txt'), indexed ? `User-agent: *\nAllow: /\nSitemap: ${siteURL}/sitemap.xml\n` : 'User-agent: *\nDisallow: /\n');
  await writeFile(join(dist, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${siteURL ? `<url><loc>${siteURL}/</loc></url>` : ''}</urlset>`);
  // Offline single-file preview. No network is required and no server mode is implied.
  let offlineBody = body;
  const files = [...new Set([...body.matchAll(/(?:src|href)="(assets\/[^"?#]+)"/g)].map(m => m[1]))];
  for (const relative of files) {
    try {
      const bytes = await readFile(join(dist, relative));
      const type = ({ '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.pdf': 'application/pdf', '.svg': 'image/svg+xml' })[extname(relative)];
      if (type) offlineBody = offlineBody.replaceAll(`"${relative}"`, `"data:${type};base64,${bytes.toString('base64')}"`);
    } catch { /* Custom missing assets remain visible to the owner rather than being invented. */ }
  }
  const scripts = await Promise.all(['assistant.js', 'name-3d.js', 'app.js'].map(file => readFile(join(root, 'src', file), 'utf8')));
  const offline = `<!doctype html>\n<html lang="id" data-theme="light" data-standalone="true"><head>${head}<style>${css}</style>${noScript}</head><body>${offlineBody}${jsonBlocks}${scripts.map(js => `<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`).join('')}</body></html>`;
  await writeFile(join(root, 'preview.html'), offline);
  const csp = `default-src 'self'; script-src 'self' 'sha256-${hash(boot)}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self' mailto:; upgrade-insecure-requests`;
  const vercel = { version: 2, framework: null, buildCommand: 'npm run build', outputDirectory: 'dist', installCommand: 'npm install --ignore-scripts', functions: { 'api/*.js': { maxDuration: 30, includeFiles: '{content/portfolio.json,src/assistant.js}' } }, headers: [{ source: '/(.*)', headers: [{ key: 'X-Content-Type-Options', value: 'nosniff' }, { key: 'X-Frame-Options', value: 'DENY' }, { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' }, { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' }, { key: 'Content-Security-Policy', value: csp }] }] };
  await writeFile(join(root, 'vercel.json'), JSON.stringify(vercel, null, 2) + '\n');
  return { indexed, dist, previewBytes: Buffer.byteLength(offline) };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { process.loadEnvFile(join(root, '.env.local')); } catch {}
  const result = await build(); console.log(`Built dist/ and preview.html (${Math.round(result.previewBytes / 1024)} KB). Indexing: ${result.indexed ? 'enabled' : 'disabled for draft'}.`);
}
