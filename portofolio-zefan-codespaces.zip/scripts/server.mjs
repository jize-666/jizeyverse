import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { dirname, resolve, join, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from './build.mjs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
try { process.loadEnvFile(join(root, '.env.local')); } catch {}
if (process.argv.includes('--production')) process.env.NODE_ENV = 'production';
await build();
const [{ default: chat }, { default: contact }, { default: status }] = await Promise.all([import('../api/chat.js'), import('../api/contact.js'), import('../api/status.js')]);
const routes = { '/api/chat': chat, '/api/contact': contact, '/api/status': status };
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8' };
const dist = join(root, 'dist'), port = Number(process.env.PORT || 4173);
const server = createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (routes[pathname]) { await routes[pathname](req, res); return; }
    if (pathname.startsWith('/api/')) { res.writeHead(404, { 'Content-Type': 'application/json' }); res.end('{"error":"Endpoint tidak ditemukan."}'); return; }
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405, { Allow: 'GET, HEAD' }); res.end(); return; }
    const candidate = resolve(dist, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!candidate.startsWith(dist + sep) || !(await stat(candidate)).isFile()) throw new Error('Not found');
    const content = await readFile(candidate);
    res.writeHead(200, { 'Content-Type': types[extname(candidate)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-cache', 'Content-Length': content.length });
    res.end(req.method === 'HEAD' ? undefined : content);
  } catch { if (!res.headersSent) res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Halaman tidak ditemukan.'); }
});
server.requestTimeout = 25000;
server.headersTimeout = 10000;
server.listen(port, '0.0.0.0', () => console.log(`Portfolio: http://localhost:${port} | Ctrl+C untuk berhenti | Edit JSON lalu jalankan ulang.`));
